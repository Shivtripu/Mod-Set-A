package com.capgemini.salesmanagement.exception;

public class ValidateProdNameException extends Exception 
{
	public ValidateProdNameException(String str)
	{
		super(str);
	}

}
