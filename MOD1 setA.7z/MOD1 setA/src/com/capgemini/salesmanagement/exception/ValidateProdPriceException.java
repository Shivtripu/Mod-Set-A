package com.capgemini.salesmanagement.exception;

public class ValidateProdPriceException extends Exception 
{
	public ValidateProdPriceException(String str)
	{
		super(str);
	}
	

}
