package com.capgemini.salesmanagement.exception;

public class ValidateProdCodeException extends Exception 
{
	public ValidateProdCodeException(String str)
	{
		super(str);
	}

}
